using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarHandler2 : MonoBehaviour
{
    Vector2 input = Vector2.zero;
    Vector2 leftThumbInput;
    [SerializeField]
    Rigidbody rb;
    public static int hitCount = 0;
    private float rightIndexInput;
    public float forwardSpeed = 1;
    public float forwardSpeedMax = 25;

    private float turnSpeed = 4;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation;
    }

    void Update()
    {

        rightIndexInput = OVRInput.Get(OVRInput.Axis1D.SecondaryIndexTrigger); // (0.0f, 1.0f)
        leftThumbInput  = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick);     // (0.0f, 0.0f), (1.0f, 1.0f)
        Debug.Log($"rightIndex {rightIndexInput}");
        Debug.Log($"leftThumb {leftThumbInput.y}");
        input.x = Input.GetAxis("Horizontal");
        input.y = Input.GetAxis("Vertical");

        addForceMetaController();

        addForceKeyboard();


        Vector3 forwardVelocity = Vector3.Project(rb.velocity, rb.transform.forward);
        if (forwardVelocity.magnitude > forwardSpeedMax)
        {
            rb.velocity = Vector3.ClampMagnitude(forwardVelocity, forwardSpeedMax) + Vector3.Project(rb.velocity, rb.transform.right);
        }


    }
    void FixedUpdate()
    {
        Vector3 pos = rb.position;

        // If out of bounds, correct position and zero X velocity
        if (pos.x > 1f)
        {
            pos.x = 1f;
            rb.velocity = new Vector3(0, rb.velocity.y, rb.velocity.z); // Stop unwanted X movement
        }
        else if (pos.x < -1f)
        {
            pos.x = -1f;
            rb.velocity = new Vector3(0, rb.velocity.y, rb.velocity.z);
        }

        rb.position = pos; // Apply position correction
    }

    public void SetInput(Vector2 inputVector)
    {
        inputVector.Normalize();
        input = inputVector;
    }


    private void OnTriggerEnter(Collider other)
    {
        //Debug.Log("HIIIT: ");

        if (other.gameObject.tag == "Obstacle")
        {
            hitCount++;
            Debug.Log("Car hit an obstacle! Total hits: " + hitCount);

        }

    }

    void addForceMetaController()
    {

        if (rightIndexInput > 0)
        {
            rb.AddForce(rb.transform.forward * forwardSpeed * rightIndexInput);
            rb.drag = 0f;
        }
        else
        {
            rb.drag = 3.0f;
        }
        if (leftThumbInput.x != 0)
        {
            rb.AddForce(rb.transform.right * turnSpeed * leftThumbInput.x);
            rb.drag = 0f;
            float forwardSpeed = Vector3.Dot(rb.velocity, rb.transform.forward);

            // Check if the forward speed is greater than 0.05
            if (forwardSpeed > 0.05f)
            {
                transform.Rotate(Vector3.up, Time.deltaTime * turnSpeed * input.x);
            }
        }
        else
        {
            rb.drag = 3.0f;
        }
    }
    void addForceKeyboard()
    {


        if (input.y > 0)
        {
            rb.AddForce(rb.transform.forward * forwardSpeed * input.y);
            rb.drag = 0f;
        }
        else
        {
            rb.drag = 3.0f;
        }
        if (input.x != 0)
        {

            rb.AddForce(rb.transform.right * turnSpeed * input.x);
            rb.drag = 0f;

            // Calculate the forward speed of the Rigidbody
            float forwardSpeed = Vector3.Dot(rb.velocity, rb.transform.forward);

            // Check if the forward speed is greater than 0.05
            if (forwardSpeed > 0.05f)
            {
                transform.Rotate(Vector3.up, Time.deltaTime * turnSpeed * input.x);
            }

        }
    }

}
