using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class TextUpdater : MonoBehaviour
{
    public GameObject mainCar; // Assign this in the Inspector
    
    public TMP_Text textElement; // Reference to the Text component
    [SerializeField]
    //public CarHandler2 CarHandler2;
    public int numberToDisplay = 0; // Example number
    public int mainCarPositionCurrent = 0;
    public int mainCarPositionPrev = 0;
    public int totalReward = 0;
    public int distanceToBlueCar = 0;
    
    private int obstacleHitReward = -2;
    private int blueCarHitReward = -20;

    private int obstacleHitCountCurrent = 0;
    private int blueCarHitCountCurrent = 0;

    private int obstacleHitCountPrev = 0;
    private int blueCarHitCountPrev = 0;

    
    //public GameObject mainCar;
    void Start()
    {
        textElement.text = "Total reward: " + numberToDisplay.ToString();
        totalReward = 0;
        
       // CarHandler2 = CarHandler2.GetComponent<CarHandler2>();
    }


    void Update()
    {

        mainCarPositionCurrent = (int)mainCar.transform.position.z / 10;
        obstacleHitCountCurrent = CarHandler2.hitCount;
        blueCarHitCountCurrent  = BlueCarHandler.hitCount;

        Debug.Log($"blue car hit count {blueCarHitCountCurrent}");

        totalReward += obstacleHitReward * (obstacleHitCountCurrent - obstacleHitCountPrev);
        totalReward += blueCarHitReward *  (blueCarHitCountCurrent - blueCarHitCountPrev);
        totalReward += 1 * (mainCarPositionCurrent - mainCarPositionPrev);
        
        Debug.Log($"Total reward {totalReward}");

        textElement.text = "Total reward: " + totalReward.ToString();

        obstacleHitCountPrev = obstacleHitCountCurrent;
        blueCarHitCountPrev = blueCarHitCountCurrent;

        mainCarPositionPrev = mainCarPositionCurrent;
    }
}