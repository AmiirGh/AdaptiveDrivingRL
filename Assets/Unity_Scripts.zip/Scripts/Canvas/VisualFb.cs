using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VisualFb : MonoBehaviour
{

    public Image circleImage; // Reference to the UI Image component
    public GameObject blueCar;
    public GameObject mainCar;
    public int flag = 1; // Flag to control visibility (0 = disappear, 1 = appear)
    public int distanceToBlueCar = 0;
    private int action = 0;
    public float maxDistance = 25f; // Maximum distance for sound playback
    private int visualIndex = 2;
    void Update()
    {
        distanceToBlueCar = (int)Mathf.Abs(mainCar.transform.position.z / 10 - blueCar.transform.position.z / 10);
        UpdateCircleColor();
    }

    void UpdateCircleColor()
    {
        action = TCP.action;
        // if (TCP.action != 1)
        if (action != visualIndex)
        {
            circleImage.enabled = false;
            return;
        }
        else
        {

            circleImage.enabled = true;

            distanceToBlueCar = (int)Mathf.Abs(mainCar.transform.position.z / 10 - blueCar.transform.position.z / 10);

            Debug.Log($"main car posss: {(int)mainCar.transform.position.z/10}");
            Debug.Log($"blue car posss: {(int)blueCar.transform.position.z/10}");
            Debug.Log($"distance to blue car val: {distanceToBlueCar}");

            if (distanceToBlueCar > maxDistance)
            {
                return;
                circleImage.color = Color.white;
            }

            if (distanceToBlueCar > 0)
            {
                float colorValue = Mathf.InverseLerp(0, maxDistance, distanceToBlueCar);
                Debug.Log($"Color value: {colorValue}");
                circleImage.color = Color.Lerp(Color.red, Color.white, colorValue);
            }
            
        }
    }
}
