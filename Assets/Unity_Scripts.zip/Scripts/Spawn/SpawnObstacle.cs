using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class SpawnObstacle : MonoBehaviour
{
    public GameObject obstaclePrefab; // Assign your obstacle prefab in the Inspector
    public Transform mainCar; // Assign the car's transform in the Inspector
    public float spawnDistanceMin = 5f *10; // Minimum Z distance from the car
    public float spawnDistanceMax = 10f * 10; // Maximum Z distance from the car

    private float timer = 0;
    private float nextSpawnZ;
    private float spawnInterval = 0.75f;
    private float xMin = -1f, xMax = 1f;
    void Start()
    {

        
    }

    void Update()
    {
        timer += Time.deltaTime;

        if (timer > spawnInterval)
        {
            ObstacleSpawner();
            timer = 0;
        }
        nextSpawnZ = mainCar.position.z + Random.Range(spawnDistanceMin, spawnDistanceMax);
    }

    void ObstacleSpawner()
    {

        float randomX = Random.Range(xMin, xMax);
        Vector3 spawnPosition = new Vector3(randomX, 0.049f, nextSpawnZ);
        GameObject newObstacle = Instantiate(obstaclePrefab, spawnPosition, Quaternion.identity);
        Destroy(newObstacle, 10f);
    }
}